import cv2
import numpy as np
import os
import time

TAMANO = 200
MUESTRAS = 150
INTERVALO = 0.10

CARPETA_DATASET = "dataset"

GESTOS = {
    0: "000",
    1: "001",
    2: "010",
    3: "011",
    4: "100",
    5: "101",
    6: "110",
    7: "111"
}


def crear_carpetas():

    if not os.path.exists(CARPETA_DATASET):
        os.makedirs(CARPETA_DATASET)

    for numero in range(8):

        carpeta = os.path.join(
            CARPETA_DATASET,
            GESTOS[numero]
        )

        if not os.path.exists(carpeta):
            os.makedirs(carpeta)


def normalizar_mano(mascara):

    contornos, _ = cv2.findContours(
        mascara,
        cv2.RETR_EXTERNAL,
        cv2.CHAIN_APPROX_SIMPLE
    )

    if not contornos:
        return None

    contorno = max(
        contornos,
        key=cv2.contourArea
    )

    area = cv2.contourArea(contorno)

    if area < 4000:
        return None

    x, y, w, h = cv2.boundingRect(contorno)

    mano = mascara[
        y:y + h,
        x:x + w
    ]

    if mano.size == 0:
        return None

    lado = max(w, h) + 40

    cuadrado = np.zeros(
        (lado, lado),
        dtype=np.uint8
    )

    inicio_x = (lado - w) // 2
    inicio_y = (lado - h) // 2

    cuadrado[
        inicio_y:inicio_y + h,
        inicio_x:inicio_x + w
    ] = mano

    cuadrado = cv2.resize(
        cuadrado,
        (TAMANO, TAMANO),
        interpolation=cv2.INTER_AREA
    )

    _, cuadrado = cv2.threshold(
        cuadrado,
        127,
        255,
        cv2.THRESH_BINARY
    )

    return cuadrado


def crear_mascara(zona):

    zona_suave = cv2.GaussianBlur(
        zona,
        (7, 7),
        0
    )

    ycrcb = cv2.cvtColor(
        zona_suave,
        cv2.COLOR_BGR2YCrCb
    )

    inferior = np.array(
        [0, 133, 77],
        dtype=np.uint8
    )

    superior = np.array(
        [255, 173, 127],
        dtype=np.uint8
    )

    mascara = cv2.inRange(
        ycrcb,
        inferior,
        superior
    )

    kernel = np.ones(
        (5, 5),
        np.uint8
    )

    mascara = cv2.morphologyEx(
        mascara,
        cv2.MORPH_OPEN,
        kernel
    )

    mascara = cv2.morphologyEx(
        mascara,
        cv2.MORPH_CLOSE,
        kernel
    )

    mascara = cv2.GaussianBlur(
        mascara,
        (5, 5),
        0
    )

    _, mascara = cv2.threshold(
        mascara,
        127,
        255,
        cv2.THRESH_BINARY
    )

    return mascara


crear_carpetas()

camara = cv2.VideoCapture(0)

camara.set(
    cv2.CAP_PROP_FRAME_WIDTH,
    640
)

camara.set(
    cv2.CAP_PROP_FRAME_HEIGHT,
    480
)

if not camara.isOpened():
    print("No se pudo abrir la camara")
    exit()


numero_actual = 0
capturando = False
contador = 0
ultimo_guardado = 0


print()
print("RECOLECTOR - TRADUCTOR BINARIO 3 BITS")
print()
print("Teclas:")
print("0 - 7 = seleccionar numero")
print("ESPACIO = iniciar captura")
print("ESC = salir")
print()
print("Seleccion actual: 0 = 000")
print()


while True:

    correcto, frame = camara.read()

    if not correcto:
        break

    frame = cv2.flip(
        frame,
        1
    )

    alto, ancho, _ = frame.shape

    x1 = int(ancho * 0.25)
    y1 = int(alto * 0.10)

    x2 = int(ancho * 0.75)
    y2 = int(alto * 0.90)

    zona = frame[
        y1:y2,
        x1:x2
    ]

    mascara = crear_mascara(
        zona
    )

    mano = normalizar_mano(
        mascara
    )

    color = (0, 200, 255)

    if mano is not None:

        color = (0, 255, 0)

        cv2.imshow(
            "Mano normalizada",
            mano
        )

    else:

        vacia = np.zeros(
            (TAMANO, TAMANO),
            dtype=np.uint8
        )

        cv2.imshow(
            "Mano normalizada",
            vacia
        )

    if capturando and mano is not None:

        tiempo_actual = time.time()

        if tiempo_actual - ultimo_guardado >= INTERVALO:

            carpeta = os.path.join(
                CARPETA_DATASET,
                GESTOS[numero_actual]
            )

            nombre = os.path.join(
                carpeta,
                f"{int(time.time() * 1000)}.png"
            )

            cv2.imwrite(
                nombre,
                mano
            )

            contador += 1
            ultimo_guardado = tiempo_actual

            if contador >= MUESTRAS:

                capturando = False

                print(
                    f"Captura terminada: "
                    f"{numero_actual} = "
                    f"{GESTOS[numero_actual]}"
                )

                print()


    cv2.rectangle(
        frame,
        (x1, y1),
        (x2, y2),
        color,
        2
    )

    texto_numero = (
        f"Numero: {numero_actual}   "
        f"Binario: {GESTOS[numero_actual]}"
    )

    cv2.putText(
        frame,
        texto_numero,
        (20, 30),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (255, 255, 255),
        2
    )

    if capturando:

        texto_captura = (
            f"CAPTURANDO: "
            f"{contador}/{MUESTRAS}"
        )

        cv2.putText(
            frame,
            texto_captura,
            (20, 65),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (0, 255, 0),
            2
        )

    else:

        cv2.putText(
            frame,
            "ESPACIO = iniciar captura",
            (20, 65),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (0, 200, 255),
            2
        )

    cv2.putText(
        frame,
        "Mueve ligeramente la mano durante la captura",
        (20, 455),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.5,
        (255, 255, 255),
        1
    )

    cv2.imshow(
        "Recolector 3 Bits",
        frame
    )

    cv2.imshow(
        "Mascara",
        mascara
    )

    tecla = cv2.waitKey(1) & 0xFF

    if tecla == 27:
        break

    if not capturando:

        if ord("0") <= tecla <= ord("7"):

            numero_actual = (
                tecla - ord("0")
            )

            contador = 0

            print(
                f"Seleccionado: "
                f"{numero_actual} = "
                f"{GESTOS[numero_actual]}"
            )

        elif tecla == 32:

            contador = 0
            capturando = True
            ultimo_guardado = 0

            print()
            print(
                f"Capturando "
                f"{numero_actual} = "
                f"{GESTOS[numero_actual]}"
            )

            print(
                "Mueve lentamente la mano "
                "sin cambiar el gesto."
            )


camara.release()
cv2.destroyAllWindows()

print()
print("Recolector cerrado.")